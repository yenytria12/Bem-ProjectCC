<?php

namespace App\Filament\Resources\KasPaymentResource\Pages;

use App\Filament\Resources\KasPaymentResource;
use Filament\Resources\Pages\ViewRecord;

class ViewKasPayment extends ViewRecord
{
    protected static string $resource = KasPaymentResource::class;
}
