<?php

namespace App\Filament\Resources\ProgramKerjaResource\Pages;

use App\Filament\Resources\ProgramKerjaResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateProgramKerja extends CreateRecord
{
    protected static string $resource = ProgramKerjaResource::class;
}
