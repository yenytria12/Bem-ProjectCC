<?php

namespace App\Filament\Resources\KasPaymentResource\Pages;

use App\Filament\Resources\KasPaymentResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateKasPayment extends CreateRecord
{
    protected static string $resource = KasPaymentResource::class;
}
