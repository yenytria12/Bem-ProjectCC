<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\URL;
use Symfony\Component\HttpFoundation\Response;

class TrustNgrokProxies
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        // Force HTTPS when accessed through ngrok
        if (str_ends_with($request->getHost(), '.ngrok-free.app') || 
            str_ends_with($request->getHost(), '.ngrok.io') ||
            str_ends_with($request->getHost(), '.ngrok.app')) {
            URL::forceScheme('https');
        }

        return $next($request);
    }
}

